From [[2015 Plank - Non-canonical language is not harder to annotate than canonical language]]:

*Why, then, is newswire considered more standard or more canonical than other text types? Obviously, this may simply be because journalists are trained writers and produce fewer errors*

Related to [[Domain Definition - Canonical vs Non-canonical]]