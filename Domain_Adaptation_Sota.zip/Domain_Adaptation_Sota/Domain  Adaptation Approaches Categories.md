From [[2018 Ramponi - Neural Unsupervised Domain Adaptation in NLP, A Survey]]

[[Domain Adaptation Approaches - Model-centric]]
[[Domain Adaptation Approaches - Data-centric]]
[[Domain Adaptation Approaches - Hybrid models]]
