https://arxiv.org/pdf/1505.07818.pdf

[[Domain Adaptation Approaches - Model-centric]] domain adaptation method

#paper #to_be_annotated 