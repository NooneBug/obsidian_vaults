https://ruder.io/thesis/neural_transfer_learning_for_nlp.pdf

Defines a [[Transfer Learning Taxonomy]]

Defines [[Supervised Domain Adaptation]]

#paper 
#phd_thesis 