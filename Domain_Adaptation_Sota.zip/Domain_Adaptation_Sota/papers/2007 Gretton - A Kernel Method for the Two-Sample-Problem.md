https://www.cs.cmu.edu/~arthurg/papers/GreBorRasSchSmo07.pdf

#paper 
#to_be_annotated 