https://www.ra.ethz.ch/CDStore/www2010/www/p751.pdf

[[Domain Adaptation Approaches - Model-centric]] domain adaptation method

#paper 
#to_be_annotated 