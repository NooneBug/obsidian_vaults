https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.721.5989&rep=rep1&type=pdf

#paper 
#phd_thesis
#to_be_annotated 