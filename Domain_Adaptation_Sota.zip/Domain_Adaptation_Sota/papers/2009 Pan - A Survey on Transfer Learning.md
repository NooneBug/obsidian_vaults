http://www-edlab.cs.umass.edu/cs689/reading/transfer-learning.pdf

Gives a large and complete definition of transfer learning, [[Domain Adaptation]]

Categorize Transfer Learning in [[Transfer Learning Taxonomy]]

#paper #to_be_annotated