https://arxiv.org/pdf/1608.07836.pdf

Defines the [[Domain definition - Variety Space]] in contrast to common [[Domain Definition - Canonical vs Non-canonical]], reports different studies which underline how different communitys can be seen as different domains indipendently if their documents comes from Canonical or Non-Canonical source, and so the classical domain notion in uneffective

*earlier findings by Silveira et al. (2014) who remark that “the most striking difference between the two types of data (Web and newswire) has to do with imperatives, which occur two orders of magnitude more often in the EWT (English Web Treebank).” A very recent paper examines word order properties and their impact on parsing taking a control experiment approach (Gulordava and Merlo, 2016). On another angle, it has been shown that tagging accuracy correlates with demographic factors such as age (Hovy and Søgaard, 2015).*

#paper 
