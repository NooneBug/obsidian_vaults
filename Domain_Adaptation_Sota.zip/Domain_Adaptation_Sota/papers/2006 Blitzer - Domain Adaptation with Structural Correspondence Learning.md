https://aclanthology.org/W06-1615.pdf

[[Domain Adaptation Approaches - Model-centric]] domain adaptation method

#paper 
#to_be_annotated 