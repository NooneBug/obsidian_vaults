Defined by [[2009 Pan - A Survey on Transfer Learning]], reported by [[2019 Ruder - Neural Transfer Learning for Natural Language Processing]] with little differences (and a bit more clear)

Given two datasets, defined as tuples (task, domain), a transfer learning approach can be classified as:

[[Inductive Transfer Learning]]
[[Transductive Transfer Learning]]
[[Unsupervised Transfer Learning]]

